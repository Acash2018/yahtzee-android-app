package com.example.project1_atripat7;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "YAHTZEE";

    // --- Dice state ---
    private final int[] dice = new int[5]; // values 1..6
    private ToggleButton[] dieBtns;
    private final Random rng = new Random();
    private int rollsLeft = 3;

    // --- UI ---
    private Button btnRollAll, btnRollChosen, btnCommit;
    private TextView tvRollsLeft, tvScore;
    private RadioGroup rgCategories;

    // --- Scoring / categories ---
    private int score = 0;
    private RadioButton rbOnes, rbTwos, rbThrees, rbFours, rbFives, rbSixes, rbYahtzee;
    private RadioButton rbChance, rbThreeKind, rbFourKind;
    private RadioButton rbFullHouse, rbSmallStraight, rbLargeStraight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Hook up views
        dieBtns = new ToggleButton[]{
                findViewById(R.id.die0),
                findViewById(R.id.die1),
                findViewById(R.id.die2),
                findViewById(R.id.die3),
                findViewById(R.id.die4)
        };
        btnRollAll    = findViewById(R.id.btnRollAll);
        btnRollChosen = findViewById(R.id.btnRollChosen);
        btnCommit     = findViewById(R.id.btnCommit);
        tvRollsLeft   = findViewById(R.id.tvRollsLeft);
        tvScore       = findViewById(R.id.tvScore);
        rgCategories  = findViewById(R.id.rgCategories);

        rbOnes   = findViewById(R.id.rbOnes);
        rbTwos   = findViewById(R.id.rbTwos);
        rbThrees = findViewById(R.id.rbThrees);
        rbFours  = findViewById(R.id.rbFours);
        rbFives  = findViewById(R.id.rbFives);
        rbSixes  = findViewById(R.id.rbSixes);
        rbYahtzee = findViewById(R.id.rbYahtzee);

        rbChance        = findViewById(R.id.rbChance);
        rbThreeKind     = findViewById(R.id.rbThreeKind);
        rbFourKind      = findViewById(R.id.rbFourKind);
        rbFullHouse     = findViewById(R.id.rbFullHouse);
        rbSmallStraight = findViewById(R.id.rbSmallStraight);
        rbLargeStraight = findViewById(R.id.rbLargeStraight);

        // First screen state
        startNewTurn(/*freshGame=*/true);

        // --- Listeners ---

        btnRollAll.setOnClickListener(v -> {
            Log.d(TAG, "Roll ALL clicked (rollsLeft=" + rollsLeft + ")");
            if (rollsLeft <= 0) return;

            // Roll every die (explicit "all true" mask)
            boolean[] mask = new boolean[5];
            Arrays.fill(mask, true);
            rollDiceWithMask(mask);
        });

        btnRollChosen.setOnClickListener(v -> {
            Log.d(TAG, "Roll CHOSEN clicked (rollsLeft=" + rollsLeft + ")");
            if (rollsLeft <= 0) return;
            if (!anyDieSelected()) {
                Log.d(TAG, "Roll CHOSEN ignored (no dice selected).");
                return;
            }
            // Snapshot current selection
            boolean[] mask = new boolean[5];
            for (int i = 0; i < 5; i++) mask[i] = dieBtns[i].isChecked();
            Log.d(TAG, "Selection mask before roll chosen: " + Arrays.toString(mask));
            rollDiceWithMask(mask);
        });

        // Dice interaction:
        //  - Tap: native ToggleButton toggling (multi-select)
        //  - Double-tap: exclusive select (only this die)
        for (int i = 0; i < dieBtns.length; i++) {
            final int idx = i;

            // React to toggle result (Android handles the actual toggle)
            dieBtns[i].setOnCheckedChangeListener((buttonView, isChecked) -> {
                Log.d(TAG, "Die toggled idx=" + idx + " checked=" + isChecked + " value=" + dice[idx]);
                updateRollChosenEnabled();
                int preview = previewSelectedCategoryPoints();
                btnCommit.setText("Choose (" + preview + " pts)");
            });

            // Double-tap detector for exclusive select
            GestureDetector detector = new GestureDetector(this,
                    new GestureDetector.SimpleOnGestureListener() {
                        @Override
                        public boolean onDoubleTap(MotionEvent e) {
                            if (rollsLeft <= 0) return true;
                            for (int j = 0; j < dieBtns.length; j++) {
                                dieBtns[j].setChecked(j == idx);
                            }
                            updateRollChosenEnabled();
                            int preview = previewSelectedCategoryPoints();
                            btnCommit.setText("Choose (" + preview + " pts)");
                            Log.d(TAG, "Die double-tapped -> exclusive select idx=" + idx);
                            return true;
                        }
                    });

            // Feed touch events to the detector (doesn't interfere with normal taps)
            dieBtns[i].setOnTouchListener((v, event) -> detector.onTouchEvent(event));
        }

        rgCategories.setOnCheckedChangeListener((group, checkedId) -> {
            Log.d(TAG, "Category selected id=" + checkedId);
            int preview = previewSelectedCategoryPoints();
            btnCommit.setText("Choose (" + preview + " pts)");
        });

        btnCommit.setOnClickListener(v -> {
            int id = rgCategories.getCheckedRadioButtonId();
            Log.d(TAG, "Commit clicked; selectedCategoryId=" + id);
            if (id == -1) return;
            int gained = previewSelectedCategoryPoints();
            score += gained;
            tvScore.setText("Score: " + score);

            RadioButton used = findViewById(id);
            used.setEnabled(false);
            used.setChecked(false);

            endTurn();
        });
    }

    // --- Turn/roll helpers ---

    private void startNewTurn(boolean freshGame) {
        rollsLeft = 3;
        Log.d(TAG, "Start new turn (freshGame=" + freshGame + "), rollsLeft=" + rollsLeft);
        tvRollsLeft.setText("Rolls left: " + rollsLeft);
        btnRollAll.setEnabled(true);
        btnRollChosen.setEnabled(true);

        // Default: nothing selected for chosen-rolls
        for (ToggleButton b : dieBtns) b.setChecked(false);
        updateRollChosenEnabled();

        if (freshGame) Arrays.fill(dice, 1);
        syncDiceImages();

        rgCategories.clearCheck();
        btnCommit.setText("Choose (0 pts)");
    }

    private void endTurn() {
        boolean anyEnabled =
                rbOnes.isEnabled() || rbTwos.isEnabled() || rbThrees.isEnabled() ||
                        rbFours.isEnabled() || rbFives.isEnabled() || rbSixes.isEnabled() ||
                        rbChance.isEnabled() || rbThreeKind.isEnabled() || rbFourKind.isEnabled() ||
                        rbFullHouse.isEnabled() || rbSmallStraight.isEnabled() || rbLargeStraight.isEnabled() ||
                        rbYahtzee.isEnabled();

        Log.d(TAG, "End turn. Any categories left? " + anyEnabled + "  score=" + score);

        if (!anyEnabled) {
            new AlertDialog.Builder(this)
                    .setTitle("Game Over")
                    .setMessage("Final score: " + score + "\nPlay again?")
                    .setPositiveButton("Yes", (d, w) -> resetGame())
                    .setNegativeButton("No", (d, w) -> finish())
                    .show();
        } else {
            startNewTurn(false);
        }
    }

    private void resetGame() {
        Log.d(TAG, "Reset game");
        score = 0;
        tvScore.setText("Score: 0");
        enableAllCategories(true);
        startNewTurn(true);
    }

    private void enableAllCategories(boolean enable) {
        rbOnes.setEnabled(enable);
        rbTwos.setEnabled(enable);
        rbThrees.setEnabled(enable);
        rbFours.setEnabled(enable);
        rbFives.setEnabled(enable);
        rbSixes.setEnabled(enable);

        rbChance.setEnabled(enable);
        rbThreeKind.setEnabled(enable);
        rbFourKind.setEnabled(enable);
        rbFullHouse.setEnabled(enable);
        rbSmallStraight.setEnabled(enable);
        rbLargeStraight.setEnabled(enable);

        rbYahtzee.setEnabled(enable);
    }

    private void rollDice(boolean rollAll) {
        if (rollsLeft <= 0) return;
        Log.d(TAG, "rollDice(rollAll=" + rollAll + "), before=" + Arrays.toString(dice));

        boolean[] mask = new boolean[5];
        if (rollAll) {
            Arrays.fill(mask, true);
        } else {
            for (int i = 0; i < 5; i++) mask[i] = dieBtns[i].isChecked();
        }
        rollDiceWithMask(mask);
    }

    // Re-roll using a frozen mask (and never repeat the same face)
    private void rollDiceWithMask(boolean[] mask) {
        Log.d(TAG, "rollDiceWithMask mask=" + Arrays.toString(mask) + " before=" + Arrays.toString(dice));
        for (int i = 0; i < 5; i++) {
            if (mask[i]) {
                int old = dice[i];
                dice[i] = rollDifferentFrom(old); // ensure it changes
                Log.d(TAG, "  -> die[" + i + "] REROLL " + old + " -> " + dice[i]);
            } else {
                Log.d(TAG, "  -> die[" + i + "] HELD at " + dice[i]);
            }
        }

        rollsLeft--;
        Log.d(TAG, "After roll: " + Arrays.toString(dice) + "  rollsLeft=" + rollsLeft);

        if (rollsLeft == 0) {
            btnRollAll.setEnabled(false);
            btnRollChosen.setEnabled(false);
            Log.d(TAG, "Roll buttons disabled (no rolls left)");
        }
        tvRollsLeft.setText("Rolls left: " + rollsLeft);
        syncDiceImages();

        int preview = previewSelectedCategoryPoints();
        btnCommit.setText("Choose (" + preview + " pts)");
        updateRollChosenEnabled();
    }

    private void syncDiceImages() {
        for (int i = 0; i < 5; i++) setDieBackgroundForValue(dieBtns[i], dice[i]);
        Log.d(TAG, "syncDiceImages -> " + Arrays.toString(dice));
    }

    private void setDieBackgroundForValue(ToggleButton btn, int value) {
        int resId;
        switch (value) {
            case 1:  resId = R.drawable.die1_selector; break;
            case 2:  resId = R.drawable.die2_selector; break;
            case 3:  resId = R.drawable.die3_selector; break;
            case 4:  resId = R.drawable.die4_selector; break;
            case 5:  resId = R.drawable.die5_selector; break;
            default: resId = R.drawable.die6_selector; break;
        }
        btn.setBackgroundResource(resId);
    }

    // --- Scoring preview/commit ---

    private int previewSelectedCategoryPoints() {
        int id = rgCategories.getCheckedRadioButtonId();
        if (id == -1) return 0;

        // Upper
        if (id == R.id.rbOnes)   return sumOfFace(1);
        if (id == R.id.rbTwos)   return sumOfFace(2);
        if (id == R.id.rbThrees) return sumOfFace(3);
        if (id == R.id.rbFours)  return sumOfFace(4);
        if (id == R.id.rbFives)  return sumOfFace(5);
        if (id == R.id.rbSixes)  return sumOfFace(6);

        // Lower
        if (id == R.id.rbYahtzee)        return isYahtzee() ? 50 : 0;
        if (id == R.id.rbChance)         return sumAll();
        if (id == R.id.rbThreeKind)      return hasNOfAKind(3) ? sumAll() : 0;
        if (id == R.id.rbFourKind)       return hasNOfAKind(4) ? sumAll() : 0;
        if (id == R.id.rbFullHouse)      return isFullHouse() ? 25 : 0;
        if (id == R.id.rbSmallStraight)  return isSmallStraight() ? 30 : 0;
        if (id == R.id.rbLargeStraight)  return isLargeStraight() ? 40 : 0;

        return 0;
    }

    private int sumOfFace(int face) {
        int s = 0;
        for (int v : dice) if (v == face) s += face;
        return s;
    }

    private int sumAll() {
        int s = 0;
        for (int v : dice) s += v;
        return s;
    }

    private int[] counts() {
        int[] c = new int[7]; // indices 1..6
        for (int v : dice) c[v]++;
        return c;
    }

    private boolean hasNOfAKind(int n) {
        for (int cnt : counts()) if (cnt >= n) return true;
        return false;
    }

    private boolean isYahtzee() {
        int v0 = dice[0];
        for (int v : dice) if (v != v0) return false;
        return true;
    }

    private boolean isFullHouse() {
        int[] c = counts();
        boolean has3 = false, has2 = false;
        for (int cnt : c) {
            if (cnt == 3) has3 = true;
            if (cnt == 2) has2 = true;
        }
        return has3 && has2;
    }

    private boolean isSmallStraight() {
        // 4-in-a-row: 1-2-3-4 OR 2-3-4-5 OR 3-4-5-6
        boolean[] p = new boolean[7];
        for (int v : dice) p[v] = true;
        return (p[1] && p[2] && p[3] && p[4]) ||
                (p[2] && p[3] && p[4] && p[5]) ||
                (p[3] && p[4] && p[5] && p[6]);
    }

    private boolean isLargeStraight() {
        // 5-in-a-row: 1-2-3-4-5 OR 2-3-4-5-6
        boolean[] p = new boolean[7];
        for (int v : dice) p[v] = true;
        return (p[1] && p[2] && p[3] && p[4] && p[5]) ||
                (p[2] && p[3] && p[4] && p[5] && p[6]);
    }

    // --- Guardrail/helpers ---

    private boolean anyDieSelected() {
        for (ToggleButton b : dieBtns) if (b.isChecked()) return true;
        return false;
    }

    private void updateRollChosenEnabled() {
        btnRollChosen.setEnabled(rollsLeft > 0 && anyDieSelected());
    }

    // Return a random face 1..6 that's different from prev
    private int rollDifferentFrom(int prev) {
        int v = rng.nextInt(6) + 1;
        while (v == prev) v = rng.nextInt(6) + 1;
        return v;
    }
}
